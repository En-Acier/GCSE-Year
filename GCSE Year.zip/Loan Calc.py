value = int(input("Input the value of the property you want to buy"))
depositP = int(input("Input the percentage of the value you are going to pay as a deposit (without the percent sign!)"))
time = int(input("How long, in years, will it take to pay back the loan?"))
depositV = (value / 100) * depositP
if time < 4 or depositP < 5 or time > 30:
    print("The time must be between 4 and 30 years. The deposit must be more than 5%")
else:
    if time <= 10 and depositP <=50:
        rate = 34.23
    elif time < 10 and depositP > 50:
        rate = 21.1
    elif time > 10 and depositP <=50:
        rate = 41.83
    elif time > 10 and depositP > 50:
        rate = 33.11

