#times table
again = 1
while again == 1:
    multiplier = int(input("Please enter a number"))
    num1 = int(input("What would you like the start point to be"))
    num2 = int(input("What would you like the end point to be"))

    while num1 <= num2:
        num3 = num1 * multiplier
        print(str(num1) + " X " + str(multiplier) + " = " + str(num3))
        num1 = num1 + 1
    again = int(input("Press 1 to play again"))


