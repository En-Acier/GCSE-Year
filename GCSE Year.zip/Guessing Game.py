import random
x = random.randint(1,50)
print("I'm thinking of a number between 1 & 50...")
guess = int(input("guess what it is"))
attempts = 1
while guess != x:
    print("wrong!")
    if x < guess:
        print("lower")
    else:
        print("higher")
    guess = int(input("guess what it is"))
    attempts = attempts + 1
print("Correct, it took you " + str(attempts) + " guess('s) to guess it!")



