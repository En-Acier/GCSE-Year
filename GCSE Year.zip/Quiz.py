#Craigs Quiz

score = 0

name = input("Welcome to the quiz. Please enter your name")

print("Question 1: How many wives did Henry VIII have?")
print("A.6")
print("B.8")
print("C.3")
print("D.None")
ans1 = input("Enter your answer here...")
if ans1.upper() == "A":
    print("Correct")
    score = score + 1
else:
    print("Incorrect, the answer was A, 6")
print("Question 2: What is the capital of Australia?")
print("A.Sydney")
print("B.Warsaw")
print("C.Canberra")
print("D.Scotland")
ans2 = input("Enter your answer here...")
if ans2.upper() == "C":
    print("Correct")
    score = score + 1
else:
    print("Incorrect, the answer was C, Canberra")
print("Question 3: Which ancient civilisation invented the dialect of sarcasm?")
print("A.The Aztecs")
print("B.The Mayans")
print("C.The Vikings")
print("D.The Incans")
ans3 = input("Enter your answer here...")
if ans3.upper() == "C":
    print("Correct")
    score = score + 1
else:
    print("Incorrect, the correct answer was C, the Vikings")
print("Question 4: Who was the first person in Britain to own a working pocket watch?")
print("A. Queen Victoria")
print("B. Charles Darwin")
print("C. Nickola Tesla")
print("D. Queen Elizabeth I")
ans4 = input("Enter your answer here...")
if ans4.upper == "D":
    print("Correct")
    score = score + 1
else:
    print("Incorrect, the correct answer was D, Queen Elizabeth I")
print("The 5th & final question: In Eastenders what relationship did Kat & Zoe Slater have?")
print("A. Mother - Daughter")
print("B. Sisters")
print("C. Cousins")
print("D. No blood relation")
ans5 = input("Enter your answer here...")
if ans5.upper == "A":
    print("Correct, in a shocking twist it was revealed that Kat was Zoe's mother")
    score = score + 1
else:
    print("Incorrect, in a shocking twist it was revealed that Kat was Zoe's mother")


percent = score/5*100
print(name + " you have scored " + str(score) + "/5 in this quiz today.That is" + str(percent) + " percent")
