Bank_Holidays_In_Month = [1,0,1,1,2,0,0,1,0,0,0,2]
def Bank_Holiday(Bank_Holidays_In_Month, x):
    y = Bank_Holidays_In_Month[x]
x = int(input("Which number month do you want to use? (Jan = 1, Feb = 2 etc.)"))
y = Bank_Holiday(Bank_Holidays_In_Month, x)
print(y)