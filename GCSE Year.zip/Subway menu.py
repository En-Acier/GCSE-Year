inches = input("Would you like a 6 inch or a 12 inch sandwich?")
if inches == "6" or "6 inches":
    price = float(1.65)
else:
    price = float(2.05)
bread = input("Would you like plain bread, wheat bread, italian bread or cheese & herb bread?")
if bread == "plain" or "plain bread":
    price = price + 0.40
elif bread =="wheat" or "wheat bread":
    price = price + 0.65
elif bread == "italian" or "italian bread":
    price = price + 0.75
else:
    price = price + 0.80
filling = input("What filling would you like? ( We have cheese & tomato, bacon & pepperoni, tuna & mayo, turkey & ham, chicken teriyaki and stake & cheese")
if filling == "cheese & tomato":
    price = price + 0.95
elif filling == "bacon & pepperoni":
    price = price + 1.10
elif filling == "tuna & mayo":
    price = price + 0.95
elif filling == "turkey & ham":
    price = price + 1.35
elif filling == "chicken teriyaki":
    price = price + 1.40
elif filling == "steak  & cheese":
    price = price + 1.95
percent = price / 100 * 5
restaurant = input("There is a small charge to eat in the restraunt." +  str(percent) + " to be exact. Do you still want to eat in?")
if restaurant == "yes":
    price = price + percent
print("You total charge for this meal will be £" + str(price))






