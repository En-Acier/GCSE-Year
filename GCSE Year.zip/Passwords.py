#passwords

username = input("Please enter your username")
if username == "TheNoblemaster":
    password = input("Please enter your password")
    if password == "password123":
        print("Access granted")
    else:
        print("Password incorrect")
if username == "Gary_":
    password = input("Please enter your password")
    if password == "_yraG":
        print("Access granted")
    else:
        print("Password incorrect")
if username == "John Cena!":
    password = input("Please enter your password")
    if password == "Do do do dooo":
        print("Access granted")
    else:
        print("Password incorrect")
else:
    print("Invalid username")



