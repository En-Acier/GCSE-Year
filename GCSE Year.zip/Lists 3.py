#1
students = ["Chloe", "Beth", "Alex", "David", "Emma", "Bruce", "Chris", "Sam",]
girlsnames = ["Chloe", "Beth", "Emma"]
boysnames = ["Alex", "David", "Bruce", "Chris", "Sam"]

for name in students:
    if name in girlsnames:
        print(name + " is a girl")
    else:
        print(name + " is a boy")
