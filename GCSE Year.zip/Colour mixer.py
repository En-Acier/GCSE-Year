colour1 = input("Enter 1 of the following colours; blue, red or black")
colour2 = input("Enter another 1 of the following colours; blue, red or black")
if colour1 == "blue" and colour2 == "red":
    print("That makes purple")
if colour1 == "red" and colour2 == "blue":
    print("That makes purple")
if colour1 == "black" and colour2 == "blue":
    print("That makes dark blue")
if colour1 == "blue" and colour2 == "black":
    print("That makes dark blue")
if colour1 == "red" and colour2 == "black":
    print("That makes dark red")
if colour1 == "black" and colour2 == "red":
    print("That makes dark red")
if colour1 == "red" and colour2 == "red":
    print("That makes more red")
if colour1 == "black" and colour2 == "black":
    print("That makes more black")
if colour1 == "blue" and colour2 == "blue":
    print("That makes more blue")


