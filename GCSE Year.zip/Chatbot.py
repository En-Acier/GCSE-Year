
genders = ["male", "female", "boy", "girl", "a boy", "a girl"]
time = datetime.datetime.now().hour
import random
moods = ["good", "well", "excellent", "fine", "decent", "okay", "ok",]

if time < 12:
    print("Good morning!")
else:
    print("Good afternoon!")
x = random.randint(0,4)
names = ["Barry", "Steve", "Gary", "Larry", "Lesley"]
bot = (names[x])
name = input("My name's " + bot + ": what's yours?")
print("Hello " + name)

botage = random.randint(15,30)
age = int(input("How old are you?"))
if age == botage:
    print("I'm " + str(age) + " too!")
else:
    print("Cool, I'm " + str(botage))

if bot == "Lesley":
    botgender = "girl"
else:
    botgender = "boy"

gender = input("Are you a boy or a girl?")
print("Well I'm obviously a " + botgender + " with a name like " + bot + "!")
if gender not in genders:
    print("Sounds interesting....")
elif botgender == gender:
    print("Wow! Great to meet another " + botgender + "!")

mood = input("So then... how are you today?")
if mood.lower() in moods:
    print("Good to hear!")
else:
    print("Awww... What's up?")
    A = input()
    print("Sounds awful :(")
