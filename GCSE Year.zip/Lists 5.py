mystring = "Chloe, Beth, Alex, David, Emma, Bruce, Chris, Sam"

mylist = mystring.split(", ")

for name in mylist:
    if name[0] == "B":
        print(name)
mystring2 = "Chloe Beth Alex David Emma Bruce Chris Sam"

mylist2 = mystring2.split(" ")

for name in mylist2:
    if name[0] == "B":
        print(name)