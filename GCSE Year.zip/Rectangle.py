#inputs
length = int(input("how long do you want the rectangle?"))
width = int(input("and how wide do you want the rectangle?"))
#loop
x = 1
while x <= length:
    print(width * "*")
    x = x + 1
