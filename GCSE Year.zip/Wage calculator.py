name = input("What is your name?")
NI = int(input("please enter your national insurance number"))
hours = int(input("How many hours (including overtime) did you work last week?"))
job = input("If you are an administrator press 1. If you are a progammer, press 2. if you are the project leader press 3")
if job == "1":
    hourly_rate = 8.07
elif job == "2":
    hourly_rate = 12.03
else:
    hourly_rate = 22.54
if hours <= 40:
    gross = hours * hourly_rate
elif hours <= 50:
    rate1 = 40 * hourly_rate
    hourly_rate2 = hourly_rate * 1.5
    hours2 = hours - 40
    rate2 = hours2 * hourly_rate2
    gross = rate1 + rate2
else:
    rate1 = 40 * hourly_rate
    hourly_rate2 = hourly_rate * 1.5
    hours2 = hours - 50
    rate2 = 10 * hourly_rate2
    rate3 = hours2 * hourly_rate2
    gross = rate1 + rate2 + rate3
NItax = 11/100 * gross
TaxAllowance = 7470/52
Taxable = gross - TaxAllowance - NItax
Tax = 25/100 * Taxable
Net = gross - NItax - Tax
gross = round(gross,2)
Net = round(Net,2)
Tax = round(Tax,2)
NItax = round(NItax,2)
print(name + " your payment is " + str(gross) + " as a gross and " + str(Net) + " after taxes. This is due to a " + str(NItax) + " National Insurance Tax, and a " + str(Tax) + " Income Tax")



