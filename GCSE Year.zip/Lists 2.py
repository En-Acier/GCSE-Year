#1
students = ["Chloe", "Beth", "Alex", "David", "Emma", "Bruce", "Chris", "Sam",]
size = len(students)
x = 0
while x < size:
    print(students[x])
    x = x + 1


#2
name = input("Please insert a name")
if students[0] == name:
    print(1)
elif students[1] == name:
    print(2)
elif students[2] == name:
    print(3)
elif students[3] == name:
    print(4)
elif students[5] == name:
    print(6)
elif students[6] == name:
    print(7)
elif students[7] == name:
    print(8)
elif students[8] == name:
    print(9)
#3
else:
    print("Not in list")


