#triangle
height = int(input("how high do you want the triangle"))
x = 1
while x <= height:
    print(x * "*")
    x = x + 1
