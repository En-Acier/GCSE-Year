#ODDS & EVENS
x = 1
y = 2
maxnum = int(input("PLease enter the maximum number"))
if maxnum > 50:
    print("That number is too big!")
else:
    print("The odd numbers are...")
    while x <= maxnum:
        print(x)
        x = x + 2
    print("The even numbers are...")
    while y <= maxnum:
        print(y)
        y = y + 2
