text_file= open("phone.txt", "r")
lines = [line.rstrip('\n') for line in open('phone.txt')]
x = input()
if x in out:
    print("yay!!!")