GendF = ["f", "F", "girl", "woman", "female",]
GendM = ["m", "boy", "man", "male"]
knight = input("Have you been knighted? ('y' for yes, 'n' for no")
gender = input("Are you male or female?")


if knight.lower() == "y":
    if gender.lower() in GendM:
        print("Your title is 'Sir'")
    elif gender.lower() in GendF:
        print("Your title is 'Dame'")
    else:
        print("Invalid gender input!")


elif knight.lower() == "n":
    doctor = input("Have you earned a doctor's degree? ('Y' for yes, 'N' for no)")
    if doctor.lower() == "y":
        print("Your title is Doctor")


    elif doctor.lower() == "n":
        age = input("Are you over the age of 16? ('Y' for yes, 'N' for no)")
        if age.lower() == "y":
            if gender.lower() in GendM:
                print("Your title is 'Mister'")
            elif gender.lower() in GendF:
                print("Your title is 'Ms'")
            else:
                print("Invalid gender input!")
        elif age.lower() == "n":
            if gender.lower() in GendM:
                print("Your title is 'Master'")
            elif gender.lower() in GendF:
                print("Your title is 'Miss'")
            else:
                print("Invalid gender input!")
        else:
            print("Invalid age input!")

    else:
        print("Invalid doctorate input!")
else:
    print("Invalid knighthood input!")

