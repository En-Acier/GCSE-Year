text_file = open("Gary.txt", "r")

x = text_file.readline()
while x != "":
    print(x)
    x = text_file.readline()
y = input("Press 1 to add to the list")
text_file.close()
text_file = open("Gary.txt", "a")
if y == "1":
    text_file.write(input("insert name"))
    text_file.write("\n")