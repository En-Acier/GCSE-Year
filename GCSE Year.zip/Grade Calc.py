#Gradez

Passes = int(input("How many passes did you get? (over all of the course)"))
Merits = int(input("How many merits did you get?"))
Distinctions = int(input("How many distinctions?"))
points1 = Passes * 70
points2 = Merits * 80
points3 = Distinctions * 90
points = points1 + points2 + points3
if points >= 1590:
    grade = "D*D*D*"
    UCAS = "420"
elif points > 1560:
    grade = "D*D*D"
    UCAS = "400"
elif points > 1530:
    grade = "D*DD"
    UCAS = "380"
elif points > 1500:
    grade = "DDD"
    UCAS = "360"
elif points > 1460:
    grade = "DDM"
    UCAS = "320"
elif points > 1420:
    grade = "DMM"
    UCAS = "280"
elif points > 1380:
    grade = "MMM"
    UCAS = "240"
elif points > 1340:
    grade = "MMP"
    UCAS = "200"
elif points > 1300:
    grade = "MPP"
    UCAS = "160"
elif points > 1260:
    grade = "PPP"
    UCAS = "120"
print("Your grade is:" + grade + " and you have " + UCAS + " UCAS Tariff points")

