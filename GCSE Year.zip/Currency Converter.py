#$$$

currency1 = input("If you want GBP converted press '1' if you want another currency converted into GBP press '2'")
if currency1 == "1":
    amount = float(input("How many £'s do you have?"))
    if amount > 500:
        service_charge = amount / 100 * 3
    else:
        service_charge = amount / 100 * 5
    print("1, USD")
    print("2, EUR")
    print("3, AUD")
    print("4, CAD")
    print("5, CHF")
    print("6, HKD")
    print("7, JPY")
    print("8,MXN")
    print("9, INR")
    print("10, NZD")
    currency2 = input("Please select the currency you want it converted into")
    if currency2 == "1":
        amount = amount * 1.6
    elif currency2 == "2":
        amount = amount * 1.2
    elif currency2 == "3":
        amount = amount * 1.6
    elif currency2 == "4":
        amount = amount * 1.6
    elif currency2 == "5":
        amount = amount * 1.5
    elif currency2 == "6":
        amount = amount * 1.3
    elif currency2 == "7":
        amount = amount * 1.3
    elif currency2 == "8":
        amount = amount * 2.1
    elif currency2 == "9":
        amount = amount * 8.4
    else:
        amount = amount * 1.9
if currency1 == "2":
    print("1, USD")
    print("2, EUR")
    print("3, AUD")
    print("4, CAD")
    print("5, CHF")
    print("6, HKD")
    print("7, JPY")
    print("8,MXN")
    print("9, INR")
    print("10, NZD")
    currency2 = input("Which currency would you like to convert into GBP?")
    amount = float(input("How much of this currency do you have?"))
    if currency2 == "1":
        amount = amount / 1.6
    elif currency2 == "2":
        amount = amount / 1.2
    elif currency2 == "3":
        amount = amount / 1.6
    elif currency2 == "4":
        amount = amount / 1.6
    elif currency2 == "5":
        amount = amount / 1.5
    elif currency2 == "6":
        amount = amount / 1.3
    elif currency2 == "7":
        amount = amount / 1.3
    elif currency2 == "8":
        amount = amount / 2.1
    elif currency2 == "9":
        amount = amount / 8.4
    else:
        amount = amount / 1.9
    service_charge = amount / 100 * 2
print("That converts to... " + str(amount) + " with a " + str(service_charge) + " service charge")



