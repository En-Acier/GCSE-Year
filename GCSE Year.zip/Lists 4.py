TGstudents = []
TKstudents = []
FYstudents = []
PNstudents = []
problems = []

for i in range(10):
    name = input("Input a name")
    house = input("Enter house: (TG, TK, FY or PN)")
    if house == "FY":
        FYstudents.append(name)
    elif house == "TG":
        TGstudents.append(name)
    elif house == "TK":
        TKstudents.append(name)
    elif house == "PN":
        PNstudents.append(name)
    else:
        problems.append(name)

print("Tregantle:" + str(TGstudents))
print("Tregonhawke" + str(TKstudents))
print("Freathy" + str(FYstudents))
print("Polhawn" + str(PNstudents))
print("Problems" + str(problems))

