#calculator

num1 = int(input("Please enter a number"))
num2 = int(input("PLease enter another number"))
choice = int(input("Press 1 for +. Press 2 for -. Press 3 for ÷. Press 4 for X (multiply)"))

if choice == 1:
    OP = "+"
    ans = num1 + num2
elif choice == 2:
    OP = "-"
    ans = num1 - num2
elif choice == 3:
    OP = "÷"
    ans = num1 // num2
elif choice == 4:
    OP = "x"
    ans = num1 * num2
else:
    print("Invalid response")

print(str(num1) + OP + str(num2) + "=" + str(ans))

