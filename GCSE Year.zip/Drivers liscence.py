#driving

name = input("Please enter your name")
years = int(input("How many years have you had a drivers liscense for?"))
points = int(input("How many points have you aquired on this liscence?"))
if years<2 or points < 6:
    print("You do not qualify for this test")
if years > 2 and points > 12:
    print("You require a time ban on your liscence")
else:
    print("You are safe to drive")
