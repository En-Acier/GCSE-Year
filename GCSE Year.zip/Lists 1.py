students = ["Gary","Larry","Barry","Sally","Carrie"]
print(students)
print(students[0])
print(students[4])
count = len(students)
print(students[count-2])
students2 = ["Frodo","Sam","Gandalf","Legolas","Gimli"]
all_students = students + students2
students[0] = "Boris"
all_students = students + students2
print(all_students)
all_students.append("Bruce")
print(all_students)
all_students.remove("Boris")
print(all_students)
all_students.sort()
print(all_students)
all_students.reverse()
print(all_students)
size = len(all_students)
print(size)
print(all_students[9])
x = 0
while x <= 9:
    print(all_students[x])
    x = x + 1