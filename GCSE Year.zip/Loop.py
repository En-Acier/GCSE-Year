#Loop
exit = "2"
while exit != "1":
    print("You are currently looping!")
    exit =(input("Press 1 to exit the loop"))
