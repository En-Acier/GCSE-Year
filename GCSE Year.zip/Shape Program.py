shape = input("Press '1' to make a rectangle, press '2' to make a triangle and press '3' for an upside down triangle")

if shape == "1":
    length = int(input("how long do you want the rectangle?"))
    width = int(input("and how wide do you want the rectangle?"))
    x = 1
    while x <= length:
        print(width * "*")
        x = x + 1
elif shape == "2":
    height = int(input("how high do you want the triangle"))
    x = 1
    while x <= height:
        print(x * "*")
        x = x + 1
elif shape == "3":
    height = int(input("how high do you want the triangle"))
    x = 1
    y = height
    while x <= height:
        print(y * "*")
        x = x + 1
        y = y - 1
else:
    print("Invalid input")



